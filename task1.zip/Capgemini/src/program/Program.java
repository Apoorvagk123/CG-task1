package program;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
//task 1
public class Program {
	
	    public int[] twoSum(int[] nums, int target) {
	        // Create a hashmap to store each number's complement and its index
	        Map<Integer, Integer> complementMap = new HashMap<>();

	        // Iterate through the array
	        for (int i = 0; i < nums.length; i++) {
	            int complement = target - nums[i];

	            // Check if the complement exists in the map
	            if (complementMap.containsKey(complement)) {
	                // Return the indices of the two numbers that add up to the target
	                return new int[] { complementMap.get(complement), i };
	            }

	            // Store the current number and its index in the map
	            complementMap.put(nums[i], i);
	        }

	        // If no solution is found, return an empty array or throw an exception
	        throw new IllegalArgumentException("No two sum solution");
	    }

	    public static void main(String[] args) {
	    	Scanner scan = new Scanner(System.in);
	    	System.out.println("Enter the array size");
	    	int size=scan.nextInt();
	    	int[] nums=new int[size];
	    	System.out.println("Enter the array elements");
	    	for(int i =0;i<=nums.length-1;i++) {
	    		nums[i]=scan.nextInt();
	    	}
	       Program solution = new Program();
	        
	        System.out.println("Enter the target");
	        int target = scan.nextInt();
	        int[] result = solution.twoSum(nums, target);
	        System.out.println("Indices: " + result[0] + ", " + result[1]); // Output: Indices: 0, 1
	    }
	}



